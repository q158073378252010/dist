package protocol // import "v2ray.com/core/common/protocol"

//go:generate errorgen
