package mux

//go:generate errorgen
